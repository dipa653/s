let name = ['Dipa','Rani','Saha'];

console.log(name);

let ages = [10,20,30]
console.log(ages[2]);

let random = ['Dipa','Saha','Rani',10,22];
console.log(random);
console.log(random.length);

let result = name.join('_')

let result = name.indexOf('Rani');
let result = name.concat(['A','B']);
let result = name.push('A');
let result = name.pop();

console.log(result);

