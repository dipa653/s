let radius = 20;
const pi = 3.1416;

//console.log(radius, pi);

// math operators +,-,*,/,**,%

let area = pi * radius * radius;

console.log(area);

let a = 10;
let b = 20;
let c = 5;
let d = 4;
console.log(a+b);
console.log(a-d);
console.log(a*c);
console.log(b/c);
console.log(b%d);


let n = 25;

let result = 'The video has'+ n + 'likes';
console.log(result);

