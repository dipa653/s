let age = 22;
let year = 2001;

console.log(age);
console.log(year);

age = 25;
console.log(age);

const cgpa = 3.75;
console.lof(cgpa);

var marks = 75;
console.lof(marks);

//comments "single line"
// variable did not start with number. example = 2age
// reserve keyword did not use to declear variable. example = let, const
// no space. example = a g e 

/* multiple 
line 
comment
*/