// template strings
const title = 'Best regards of 2022';
const author = 'Dipa';
const likes = 50;

//concatenation way
let result = 'The blog called' + title + 'by' + author + 'has' + likes + 'likes';
console.log(result);

//template string way
let result = `The blog called ${title} by ${author} has ${likes} likes`;
console.log(result);

//creating html templates
let html = `
<h2>${title}</h2>
<p>By ${author}</p>
<span>This Blog Has ${likes} likes</spam>
`;
console.log(html);
