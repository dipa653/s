// boolean and comparisons
console.log(true, false, "true","false");

//methods can return booleans
let email = 'dipa@gmail.com';
let name = ['Dipa', 'Saha'];

let result = email.includes('!');
let result = name.includes('Rani');

console.log(result);


//comparison operators
let age = 25;

console.log(age == 25); 
console.log(age == 30); 
console.log(age != 30); 
console.log(age > 20); 
console.log(age < 20); 
console.log(age <= 25);
console.log(age >= 25);

//comparison operators

let name = 'shaun';

console.log(name == 'shaun'); 
console.log(name == 'Shaun'); 
console.log(name > 'crystal'); 
console.log(name > 'Shaun'); 
console.log(name > 'Crystal');