// strings
console.lof('Dipa, Saha')

let email = 'dipasaha@gmail.com';
console.lof(email);

// string concatenation
let firstname = 'Dipa';
let lastname = 'Saha';

let fullname = firstname + lastname;
console.lof(fullname);

let fullnamee = firstname + ' ' + lastname;
console.lof(fullnamee);

// getting characters
console.log(fullnamee[0]);
console.log(fullnamee[2]);
console.log(fullnamee[5]);

// string length
console.log(fullnamee.length);

// string methods
console.log(fullnamee.toUpperCase());
console.log(fullnamee.toLowerCase());
let result = fullnamee.toLowerCase();
console.log('result');

let index = email.indexOf('g');
console.log(index);

// common string methods

let emaill = email.lastIndexOf('a');
let emaill = email.slice(2,6);

consolele.log(emaill);

