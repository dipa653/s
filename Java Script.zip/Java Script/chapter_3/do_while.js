// do while loops
let i = 3;
do{ 'console.log('val of i is: ', i);
i++; } while(i < 5);