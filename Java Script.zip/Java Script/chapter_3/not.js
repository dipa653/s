// logical NOT (!)


let user = false;

if(user) {
console.log('you must be logged in to continue');
}
console.log(!true); 
console.log(!false);