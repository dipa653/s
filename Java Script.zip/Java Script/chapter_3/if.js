// if statements 

const age = 25;
if(age > 20)
{ 
console.log('you are over 20 years old');
}

const ninjas = ['shaun', 'ryu', 'chun-li', 'yoshi'];

if(ninjas.length > 4)
{ 
 console.log("that's a lot of ninjas");
}