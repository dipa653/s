// switch statements 

const grade = 'C';
switch(grade) { 
    case 'A':
       console.log('you got an A!");
break; 
    case 'B':
       console.log('you got an B!'); break; 
    case 'c': 
       console.log('you got an C!');
break; 
case 'D': 
       console.log('you got an D!');
break 
case 'E': 
       console.log('you got an E!');
   break; 
default:
       console.log('hot a valid grade');
}